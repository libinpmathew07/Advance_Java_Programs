/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package collectionhashset;

import java.util.HashSet;
import java.util.Iterator;


public class CollectionHashSet 
{
    HashSet<String> g=new HashSet<>();
  void get()
  {
      g.add("azar");
      g.add("mohan");
      g.add("raj");
      g.add("raj");
     
      System.out.println("Remove elements"+g.remove("mohan"));
      System.out.println("YourSize is:"+g.size());
      System.out.println("Search the data"+g.contains("mohan"));
     
      Iterator h=g.iterator();
      while(h.hasNext())
      {
          System.out.println("Your value is:"+h.next());
      }
  }
    public static void main(String[] args)
    {
       CollectionHashSet g1=new CollectionHashSet();
       g1.get();
    }
}
