/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package a;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DemoServlet1 extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
       try
       {
          response.setContentType("text/html");
          PrintWriter ot=response.getWriter();
          String u=request.getParameter("foo1");
          String p=request.getParameter("doo1");
          String e=request.getParameter("email");
          
           ot.println("<center>");
           ot.println("<table border='1'>");
           ot.println("<th>Uname</th>");
           ot.println("<th>Pass</th>");
           ot.println("<th>Email</th>");
           ot.println("<tr>"
                   + "<td>"+u+"</td><td>"+p+"</td><td>"+e+"</td></tr>");
           
           ot.println("</table>");
           ot.println("</center>");
       }
       catch(Exception t)
       {
           System.out.println(t);
       }
    }

    
}
