/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package infotry2;

import java.util.Scanner;


public class Infotry2
{
  String name=null;
  Scanner g=new Scanner(System.in);
  void get1()
  {
      try
      {
     // System.out.println("Enter the String value is:\n");
      //name=g.next();
      System.out.println("String Value is:\n"+name.length());
      }
      catch(NullPointerException t)
      {
          System.out.println(t);
      }
  }
}
class Demo
{
    public static void main(String[] args) 
    {
       Infotry2 h=new Infotry2();
       h.get1();
    }
}
