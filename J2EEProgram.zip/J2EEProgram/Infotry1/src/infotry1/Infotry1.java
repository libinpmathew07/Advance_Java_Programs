/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package infotry1;

import java.util.Scanner;


public class Infotry1 
{
  int inp1,inp2,process;
    Scanner g=new Scanner(System.in);
  void get1()
  {
      try
      {
         System.out.println("Enter the values is:\n");
         inp1=g.nextInt();
         inp2=g.nextInt();
         process=inp1/inp2;
        
         System.out.println("Your Value is:\n"+process);
          
      }
      catch(ArithmeticException t)
      {
          System.out.println("plz check an input"+t);
      }
      finally
      {
      System.out.println("finally block");
      }
  }
  
}
class Demo
{
    public static void main(String[] args)
    {
    Infotry1 h=new Infotry1();
    h.get1();
    }
}
