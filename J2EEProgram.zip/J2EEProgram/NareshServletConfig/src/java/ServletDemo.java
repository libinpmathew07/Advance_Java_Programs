/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author admin
 */
public class ServletDemo extends HttpServlet {

   

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
       try
       {
           response.setContentType("text/html");
           PrintWriter out=response.getWriter();
           ServletConfig v=getServletConfig();
           String g=v.getInitParameter("demo");
           out.println("Welcome:"+g);
       }
       catch(Exception t)
       {
           System.out.println(t);   
       }
    }
}
