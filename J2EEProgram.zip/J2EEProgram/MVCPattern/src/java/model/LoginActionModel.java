/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.servlet.RequestDispatcher;

/**
 *
 * @author admin
 */
public class LoginActionModel 
{
   public String uname,pass;

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

   
   public boolean sample()
   {
       if(uname.equals("admin")&&pass.equals("admin"))
       {
           return true;
       }
       else
       {
           return false;
       }
   }
}
