/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package updatableresultsetex1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author admin
 */
public class UpdatableResultSetEx1 {

   
    public static void main(String[] args) throws SQLException 
    {
         Connection con = ConnectionFactory.getConnection();
                Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                ResultSet rs = st.executeQuery("select empno, name, sal, depno from employees2");
                while(rs.next())
                {
                        System.out.print(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3)+" "+rs.getInt(4));
                        if(rs.getInt(4)==201)
                        {
                                rs.updateInt(3, rs.getInt(1));
                                rs.updateRow();
                                System.out.println("--- Updated");
                        }
                        else
                        {
                                System.out.println("Not updated");
                        }
                }
        }
    }

