/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package localmessage;

import java.util.Locale;
import java.util.ResourceBundle;


public class LocalMessage 
{

   
    public static void main(String[] args) 
    {
        // TODO code application logic here
        try
        {
        Locale l1=new Locale("de","DE");
        ResourceBundle f1=ResourceBundle.getBundle("MessageBundle", l1);
        System.out.println("Welcome1"+f1.getString("kk"));
        Locale l2=new Locale("zn","ZN");
        ResourceBundle f2=ResourceBundle.getBundle("MessageBundle", l2);
        System.out.println("Welcome2"+f2.getString("kk"));
        }
        catch(Exception t)
        {
            System.out.println(t);
        }
        
    }
}
