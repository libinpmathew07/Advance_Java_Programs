/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package file1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.SequenceInputStream;
import java.util.Scanner;

/**
 *
 * @author admin
 */
public class File1 
{
   
    void ss()throws IOException
    {
        try
        {
            FileOutputStream fis=new FileOutputStream("F:\\sam2.txt");
            FileInputStream f2=new FileInputStream("F:\\sam1.txt");
            FileInputStream f1=new FileInputStream("F:\\sam.txt");
            
            SequenceInputStream s1=new SequenceInputStream(f1, f2);
            System.out.println("file wrting sucess....");
            int i;
            while((i=s1.read())!=-1)
            {
                //System.out.print((char)i);
                fis.write(i);
            }
        }
        catch(Exception j)
        {
            System.out.println(j);
        }
    }
}
class Demo
{
    public static void main(String[] args) throws IOException 
    {
     File1 k=new File1();
     k.ss();
    }
}
