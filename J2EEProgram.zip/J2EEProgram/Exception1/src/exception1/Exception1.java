/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exception1;

/**
 *
 * @author admin
 */
public class Exception1 
{
   void get()
   {
      try
      {
          //int a=100/0;
          int a[]=new int[2];
          a[3]=100;
          System.out.println("NormalFlow"+a);
      }
      catch(ArrayIndexOutOfBoundsException h)
      {
          System.out.println(h);
      }
       
   }
   
}
class Demo
{
    public static void main(String[] args) 
    {
      Exception1 g=new Exception1();
      g.get();
    }
}
