/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package infomethodoverloding;

import java.util.Scanner;


public class InfoMethodOverloding 
{
    Scanner g=new Scanner(System.in);
  void employee(int cusid)
  {
     int c=cusid;
      System.out.println("Your Cus Id:\n"+c);
      
  }
  void employee(String empname,int empid)
  {
      String e1=empname;
      int r=empid;
      
      System.out.println("Method-2"+e1+""+r);
  }
}
class Sample
{
    public static void main(String[] args) 
    {
       InfoMethodOverloding h=new InfoMethodOverloding();
       h.employee(121);
       h.employee("mohan",123);
    }
}
