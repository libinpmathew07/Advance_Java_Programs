/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication27;

/**
 *
 * @author admin
 */
public class JavaApplication27
{

    /**
     * @param args the command line arguments
     */
}
class D extends JavaApplication27
{
    
}
class Demo
{
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
