/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package scrollableresultset;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author admin
 */
public class ScrollableResultSet {

   
    public static void main(String[] args) throws SQLException
    {
       Connection con = ConnectionFactory.getConnection();
                Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
                ResultSet rs = st.executeQuery("select * from employees");
                //Now the pointer is in beforeFirst position
                while(rs.next())
                {
                        System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4));
                }
                //Now the pointer is at after last row
                //To get the second row
                System.out.println("\n\n");
                rs.absolute(2);
                System.out.println("2nd row: "+rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4));
                rs.absolute(-1);
                System.out.println("last row: "+rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4));
                rs.relative(-2);
                System.out.println("last 3rd row: "+rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4));
        }
    }

