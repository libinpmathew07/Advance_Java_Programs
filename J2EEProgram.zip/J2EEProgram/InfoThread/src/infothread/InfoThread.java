/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package infothread;


import java.util.Scanner;


public class InfoThread extends Thread
{
    int pid;
    String pname;
    Scanner h=new Scanner(System.in);
 public  void run()
  {
      try
      {
          System.out.println("Wating for Input.....");    
      System.out.println("Thread Name"+currentThread().getName());
      Thread.sleep(10000);
          System.out.println("Now We can I/P ready...");
          System.out.println("Enter the pid and Pname");
          pid=h.nextInt();
          pname=h.next();
          System.out.println("Your Id and name:\n"+pid+""+pname);
      }
      catch(InterruptedException t)
      {
          System.out.println(t);
      }
  }
 void get1()
 {
     System.out.println("Normal Method");
 }
}
class Demo
{
    public static void main(String[] args) 
    {
       InfoThread t1=new InfoThread();
       
       t1.setName("NIIT");
       t1.start();
       
    }
}
