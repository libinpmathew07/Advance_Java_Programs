/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package resultsetmetadata;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

/**
 *
 * @author admin
 */
public class JDBCTest 
{
   public static void main(String args[])
   {
       Connection conn = null;
   
   Statement statement = null; 
   String query = "select EMPLOYEE_ID, " + "FIRST_NAME from EMPLOYEES"; 
   try
   {	
       //get connection 
       conn = JDBCUtil.getConnection();
       //create statement 
       statement = conn.createStatement();  
       //execute query 
       ResultSet rs = statement.executeQuery(query); 
       //get ResultSetMetaData 
       ResultSetMetaData rsmd = rs.getMetaData(); 
       //Result set meta data
       System.out.println("Total cols: " + rsmd.getColumnCount()); 
       System.out.println("Column name: " + rsmd.getColumnName(1));
       System.out.println("Column type: " + rsmd.getColumnTypeName(1));
       //close connection 
       statement.close(); 
       conn.close(); 
   }
catch(Exception e)
{ 
    e.printStackTrace(); 
} 
}
}
   
